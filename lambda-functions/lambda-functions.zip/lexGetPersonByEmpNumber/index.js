'use strict';
const test =  {
  "currentIntent": {
    "slots": {
      "EmployeeNumber": 1
    },
    "name": "GetPersonByEmployeeNumber",
    "confirmationStatus": "None"
  },
  "bot": {
    "alias": "$LATEST",
    "version": "$LATEST",
    "name": "AskApplaud"
  },
  "userId": "John",
  "invocationSource": "DialogCodeHook",
  "outputDialogMode": "Text",
  "messageVersion": "1.0",
  "sessionAttributes": {}
};
const request = require('request');

/**
 * This sample demonstrates an implementation of the Lex Code Hook Interface
 * in order to serve a sample bot which manages orders for flowers.
 * Bot, Intent, and Slot models which are compatible with this sample can be found in the Lex Console
 * as part of the 'OrderFlowers' template.
 *
 * For instructions on how to set up and test this bot, as well as additional samples,
 *  visit the Lex Getting Started documentation.
 */


// --------------- Helpers to build responses which match the structure of the necessary dialog actions -----------------------

function elicitSlot(sessionAttributes, intentName, slots, slotToElicit, message) {
  return {
    sessionAttributes,
    dialogAction: {
      type: 'ElicitSlot',
      intentName,
      slots,
      slotToElicit,
      message,
    },
  };
}

function close(sessionAttributes, fulfillmentState, message) {
  return {
    sessionAttributes,
    dialogAction: {
      type: 'Close',
      fulfillmentState,
      message,
    },
  };
}

function delegate(sessionAttributes, slots) {
  return {
    sessionAttributes,
    dialogAction: {
      type: 'Delegate',
      slots,
    },
  };
}

// ---------------- Helper Functions --------------------------------------------------

function buildValidationResult(isValid, violatedSlot, messageContent) {
  if (messageContent == null) {
    return {
      isValid,
      violatedSlot,
    };
  }
  return {
    isValid,
    violatedSlot,
    message: { contentType: 'PlainText', content: messageContent },
  };
}

function validateEmployeeNumber(employeeNumber) {
  if (!Number.isInteger(parseInt(employeeNumber))) {
    return buildValidationResult(false, 'EmployeeNumber', `Sorry, the employee number must be a number`);
  }
  return buildValidationResult(true, null, null);
}

// --------------- Functions that control the bot's behavior -----------------------

/**
 * Performs dialog management and fulfillment for ordering flowers.
 *
 * Beyond fulfillment, the implementation of this intent demonstrates the use of the elicitSlot dialog action
 * in slot validation and re-prompting.
 *
 */
function getPersonByEmployeeNumber(intentRequest, callback) {
  const employeeNumber = intentRequest.currentIntent.slots.EmployeeNumber;
  const source = intentRequest.invocationSource;

  if (source === 'DialogCodeHook') {
    // Perform basic validation on the supplied input slots.  Use the elicitSlot dialog action to re-prompt for the first violation detected.
    const slots = intentRequest.currentIntent.slots;
    const validationResult = validateEmployeeNumber(employeeNumber);
    if (!validationResult.isValid) {
      slots[`${validationResult.violatedSlot}`] = null;
      callback(elicitSlot(intentRequest.sessionAttributes, intentRequest.currentIntent.name, slots, validationResult.violatedSlot, validationResult.message));
      return;
    }
    const outputSessionAttributes = intentRequest.sessionAttributes || {};
    callback(delegate(outputSessionAttributes, intentRequest.currentIntent.slots));
    return;
  }


  request(
    {
      uri: `https://jsonplaceholder.typicode.com/users/${employeeNumber}`,
      json:true
    },
    (error, response, data) => {
      const sessionAttributes = intentRequest.sessionAttributes || {};
      sessionAttributes.website = data.website;
      callback(
        close(
          sessionAttributes,
          'Fulfilled',
          {
            contentType: 'PlainText',
            content: `Employee number ${employeeNumber} is ${data.name} and they live in ${data.address.street} street, taking you to their profile page now`
          }
        )
      );
    }
  );


}

// --------------- Intents -----------------------

/**
 * Called when the user specifies an intent for this skill.
 */
function dispatch(intentRequest, callback) {
  console.log(`dispatch userId=${intentRequest.userId}, intentName=${intentRequest.currentIntent.name}`);

  const intentName = intentRequest.currentIntent.name;

  // Dispatch to your skill's intent handlers
  if (intentName === 'GetPersonByEmployeeNumber') {
    return getPersonByEmployeeNumber(intentRequest, callback);
  }
  throw new Error(`Intent with name ${intentName} not supported`);
}

// --------------- Main handler -----------------------

// Route the incoming request based on intent.
// The JSON body of the request is provided in the event slot.
exports.handler = (event, context, callback) => {
  try {
    // By default, treat the user request as coming from the America/New_York time zone.
    process.env.TZ = 'America/New_York';
    console.log(`event.bot.name=${event.bot.name}`);

    /**
     * Uncomment this if statement and populate with your Lex bot name and / or version as
     * a sanity check to prevent invoking this Lambda function from an undesired Lex bot or
     * bot version.
     */

    if (event.bot.name !== 'AskApplaud') {
      callback('Invalid Bot Name');
    }

    dispatch(event, (response) => callback(null, response));
  } catch (err) {
    callback(err);
  }
};
